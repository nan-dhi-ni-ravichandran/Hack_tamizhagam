// document.getElementById("authority-login-form").addEventListener("submit", function (event) {
//     event.preventDefault();  // Prevent default form submission

//     let isValid = true;
//     const aadhar = document.getElementById("aadhar").value;
//     const password = document.getElementById("password").value;
//     const aadharError = document.getElementById("aadhar-error");

//     // Aadhar validation: Check if the number is exactly 12 digits
//     if (aadhar.length !== 12 || isNaN(aadhar)) {
//         isValid = false;
//         document.getElementById("aadhar").classList.add("error");
//         aadharError.style.display = "block";
//     } else {
//         document.getElementById("aadhar").classList.remove("error");
//         aadharError.style.display = "none";
//     }

//     // If form is valid, check if Aadhar and password match with the saved data
//     if (isValid) {
//         const storedAadhar = localStorage.getItem('aadhar');    // Retrieve saved Aadhar from localStorage
//         const storedPassword = localStorage.getItem('password'); // Retrieve saved password from localStorage

//         // Compare Aadhar and Password
//         if (aadhar === storedAadhar && password === storedPassword) {
//             alert("Login successful!");
//             // Add any redirect logic if needed
//         } else {
//             alert("No user found with the provided credentials.");
//         }
//     }
    
// });






document.getElementById("login-button").onclick = function(event) {
    event.preventDefault(); // Prevent default form submission

    let isValid = true;
    const aadhar = document.getElementById("aadhar").value;
    const password = document.getElementById("password").value;
    const aadharError = document.getElementById("aadhar-error");

    // Aadhar validation: Check if the number is exactly 12 digits
    if (aadhar.length !== 12 || isNaN(aadhar)) {
        isValid = false;
        document.getElementById("aadhar").classList.add("error");
        aadharError.style.display = "block";
    } else {
        document.getElementById("aadhar").classList.remove("error");
        aadharError.style.display = "none";
    }

    // If form is valid, check if Aadhar and password match with the saved data
    if (isValid) {
        const storedAadhar = localStorage.getItem('aadhar');    // Retrieve saved Aadhar from localStorage
        const storedPassword = localStorage.getItem('password'); // Retrieve saved password from localStorage

        // Compare Aadhar and Password
        if (aadhar === storedAadhar && password === storedPassword) {
            alert("Login successful!");
            window.location.href = "index1.html"; // Redirect to index1.html on success
        } else {
            alert("No user found with the provided credentials.");
        }
    }
};


