
let currentIndex = 0;

function moveSlide(direction) {
    const slides = document.querySelector(".carousel-images");
    const totalSlides = slides.children.length;
    
    currentIndex += direction;

    if (currentIndex >= totalSlides) {
        currentIndex = -1; // Loop back to first image
    } else if (currentIndex < 0) {
        currentIndex = totalSlides - 1; // Loop to last image
    }

    slides.style.transform = `translateX(-${currentIndex * 100}%)`;
}

// Auto-slide every 3 seconds
setInterval(() => {
    moveSlide(1);
}, 3000);
