document.getElementById("authority-signup-form").addEventListener("submit", function (event) {
    event.preventDefault();  // Prevent default form submission

    let isValid = true;

    // Age validation: Age must be greater than 22
    const age = document.getElementById("age").value;
    const ageError = document.getElementById("age-error");
    if (age <= 22) {
        isValid = false;
        document.getElementById("age").classList.add("error");
        ageError.style.display = "block";
    } else {
        document.getElementById("age").classList.remove("error");
        ageError.style.display = "none";
    }

    // Aadhar validation: Aadhar number must be exactly 12 digits
    const aadhar = document.getElementById("aadhar").value;
    const aadharError = document.getElementById("aadhar-error");
    if (aadhar.length !== 12 || isNaN(aadhar)) {
        isValid = false;
        document.getElementById("aadhar").classList.add("error");
        aadharError.style.display = "block";
    } else {
        document.getElementById("aadhar").classList.remove("error");
        aadharError.style.display = "none";
    }

    // If form is valid, proceed with saving data to localStorage
    if (isValid) {
        localStorage.setItem('aadhar', aadhar);               // Save Aadhar to localStorage
        localStorage.setItem('password', 'Coimbatore@123');    // Save default password to localStorage
        alert("Signup successful! You can now login.");
        window.location.href = "authority_login.html"; // Redirect to login page
    }
});
