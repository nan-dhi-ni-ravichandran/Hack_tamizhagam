console.log('App.js loaded');

document.getElementById('search-btn').addEventListener('click', () => {
  console.log('Search button clicked');
  const searchQuery = document.getElementById('search-bar').value;
  console.log('Search query:', searchQuery);
  
  // Rest of your search logic here
});




console.log('App is running');

// Initialize the map with Coimbatore's coordinates
const map = L.map('map').setView([11.0168, 76.9558], 13); // Centered at Coimbatore

// Add OpenStreetMap tile layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Create a marker for a road hazard (example marker in Coimbatore)
const marker = L.marker([11.0168, 76.9558]).addTo(map);
marker.bindPopup('<b>Road Hazard Location</b><br>Reported Hazard').openPopup();

// Geocoder control for searching locations
const geocoder = L.Control.Geocoder.nominatim();

// Handle search button click
document.getElementById('search-btn').addEventListener('click', () => {
  const searchQuery = document.getElementById('search-bar').value;
  
  // Use geocoder to search for the location
  geocoder.geocode(searchQuery, function(results) {
    if (results.length > 0) {
      // Get the first result
      const result = results[0];
      
      // Move the map to the found location
      map.setView(result.center, 13);

      // Move the marker to the new location
      marker.setLatLng(result.center);

      // Update popup content properly
      marker.bindPopup(`<b>${result.name}</b><br>${searchQuery}`).openPopup();
    } else {
      alert("Location not found.");
    }
  });
});

// Handle form submission
document.getElementById('submit-report').addEventListener('click', () => {
  alert('Report submitted!');
});
