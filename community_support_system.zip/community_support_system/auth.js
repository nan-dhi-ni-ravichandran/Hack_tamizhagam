document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('login-form');

    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const aadhar = document.getElementById('login-aadhar').value;
            const password = document.getElementById('login-password').value;

            // Retrieve user data from localStorage
            const storedUser = localStorage.getItem(aadhar);

            if (storedUser) {
                const userData = JSON.parse(storedUser);

                // Check if the entered password matches the stored password
                if (userData.password === password) {
                    alert('Login Successful!');
                    window.location.href = 'index.html'; // Redirect to the main page
                } else {
                    alert('Invalid password. Please try again.');
                }
            } else {
                alert('User not found. Please sign up first.');
            }
        });
    }

    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', function (e) {
            e.preventDefault();
            
            const name = document.getElementById('name').value;
            const phone = document.getElementById('phone');
            const aadhar = document.getElementById('aadhar');
            const age = document.getElementById('age');
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirm-password');

            const phoneError = document.getElementById('phone-error');
            const aadharError = document.getElementById('aadhar-error');
            const ageError = document.getElementById('age-error');
            const passwordError = document.getElementById('password-error');

            let isValid = true;

            // Phone number validation (must be 10 digits)
            if (!/^\d{10}$/.test(phone.value)) {
                phone.classList.add('error');
                phoneError.style.display = 'block';
                isValid = false;
            } else {
                phone.classList.remove('error');
                phoneError.style.display = 'none';
            }

            // Aadhar number validation (must be 12 digits)
            if (!/^\d{12}$/.test(aadhar.value)) {
                aadhar.classList.add('error');
                aadharError.style.display = 'block';
                isValid = false;
            } else {
                aadhar.classList.remove('error');
                aadharError.style.display = 'none';
            }

            // Age validation (must be greater than 16)
            if (parseInt(age.value) <= 16 || isNaN(parseInt(age.value))) {
                age.classList.add('error');
                ageError.style.display = 'block';
                isValid = false;
            } else {
                age.classList.remove('error');
                ageError.style.display = 'none';
            }

            // Password confirmation check
            if (password.value !== confirmPassword.value) {
                password.classList.add('error');
                confirmPassword.classList.add('error');
                passwordError.style.display = 'block';
                isValid = false;
            } else {
                password.classList.remove('error');
                confirmPassword.classList.remove('error');
                passwordError.style.display = 'none';
            }

            if (!isValid) return;

            const userData = { 
                name, 
                phone: phone.value, 
                aadhar: aadhar.value, 
                age: age.value, 
                password: password.value 
            };

            localStorage.setItem(aadhar.value, JSON.stringify(userData)); // Store user data
            alert('Signup Successful! You can now login.');
            window.location.href = 'login.html';
        });
    }
});
