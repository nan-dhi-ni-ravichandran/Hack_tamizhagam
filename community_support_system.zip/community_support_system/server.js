const mongoose = require("mongoose");
const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

// Serve static files
app.use("/images", express.static(path.join(__dirname, "images")));
app.use("/css", express.static(path.join(__dirname, "css")));
app.use("/js", express.static(path.join(__dirname, "js")));

// Serve HTML pages
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "first.html")));
app.get("/signup.html", (req, res) => res.sendFile(path.join(__dirname, "signup.html")));
app.get("/login.html", (req, res) => res.sendFile(path.join(__dirname, "login.html")));
app.get("/index.html", (req, res) => res.sendFile(path.join(__dirname, "index.html")));
app.get("/authority_signup.html", (req, res) => res.sendFile(path.join(__dirname, "authority_signup.html")));
app.get("/authority_login.html", (req, res) => res.sendFile(path.join(__dirname, "authority_login.html")));
app.get("/index1.html", (req, res) => res.sendFile(path.join(__dirname, "index1.html")));

// ✅ MongoDB Connection
const mongoURL = "mongodb://localhost:27017/Community_Support_System";
mongoose.connect(mongoURL, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("✅ MongoDB connected successfully"))
    .catch((err) => console.error("❌ MongoDB connection error:", err));

// ✅ Citizen Schema & Model
const citizenSchema = new mongoose.Schema({
    name: String,
    phone: String,
    aadhar: { type: String, unique: true },
    age: Number,
    password: String,
});

const Citizen = mongoose.model("Citizen", citizenSchema);

// ✅ Admin Schema & Model
const adminSchema = new mongoose.Schema({
    name: String,
    age: Number,
    aadhar: { type: String, unique: true },
    authority: String,
    password: { type: String, default: "Coimbatore@123" },
});

const Admin = mongoose.model("Admin", adminSchema);

// ✅ Citizen Signup API
app.post("/api/citizen/signup", async (req, res) => {
    try {
        const { name, phone, aadhar, age, password } = req.body;

        if (!name || !phone || !aadhar || !age || !password) {
            return res.status(400).json({ message: "All fields are required!" });
        }

        if (!/^\d{10}$/.test(phone)) {
            return res.status(400).json({ message: "Phone number must be exactly 10 digits." });
        }

        if (!/^\d{12}$/.test(aadhar)) {
            return res.status(400).json({ message: "Aadhar number must be exactly 12 digits." });
        }

        if (age < 16) {
            return res.status(400).json({ message: "Age must be greater than 16." });
        }

        const existingCitizen = await Citizen.findOne({ aadhar });
        if (existingCitizen) {
            return res.status(400).json({ message: "Citizen already exists!" });
        }

        const newCitizen = new Citizen({ name, phone, aadhar, age, password });
        await newCitizen.save();

        res.status(201).json({ message: "Citizen signup successful!" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ✅ Citizen Login API
app.post("/api/citizen/login", async (req, res) => {
    try {
        const { aadhar, password } = req.body;

        if (!aadhar || !password) {
            return res.status(400).json({ message: "Aadhar and password are required!" });
        }

        const citizen = await Citizen.findOne({ aadhar });
        if (!citizen) {
            return res.status(404).json({ message: "User not found!" });
        }

        if (citizen.password !== password) {
            return res.status(401).json({ message: "Invalid password!" });
        }

        res.status(200).json({ message: "Login successful!" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ✅ Admin Signup API
app.post("/api/admin/signup", async (req, res) => {
    try {
        const { name, age, aadhar, authority } = req.body;

        if (!name || !age || !aadhar || !authority) {
            return res.status(400).json({ message: "All fields are required!" });
        }

        const existingAdmin = await Admin.findOne({ aadhar });
        if (existingAdmin) {
            return res.status(400).json({ message: "Admin already exists!" });
        }

        const newAdmin = new Admin({ name, age, aadhar, authority });
        await newAdmin.save();

        res.status(201).json({ message: "Admin signup successful!" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ✅ Admin Login API
app.post("/api/admin/login", async (req, res) => {
    try {
        const { aadhar, password } = req.body;

        if (!aadhar || !password) {
            return res.status(400).json({ message: "Aadhar and password are required!" });
        }

        const admin = await Admin.findOne({ aadhar });
        if (!admin) {
            return res.status(404).json({ message: "Admin not found!" });
        }

        if (admin.password !== password) {
            return res.status(401).json({ message: "Invalid password!" });
        }

        res.status(200).json({ message: "Admin login successful!" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Start Server
const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));


